**To delete a group**

The following ``delete-group`` example deletes the specified Greengrass group. ::

    aws greengrass delete-group \
        --group-id "4e22bd92-898c-436b-ade5-434d883ff749"

This command produces no output.
