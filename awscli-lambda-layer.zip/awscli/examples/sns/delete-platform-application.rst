**To delete a platform application**

The following ``delete-platform-application`` example deletes the specified platform application. ::

    aws sns delete-platform-application \
        --platform-application-arn arn:aws:sns:us-west-2:123456789012:app/ADM/MyApplication

This command produces no output.
