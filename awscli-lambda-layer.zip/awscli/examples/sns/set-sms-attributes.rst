**To set SMS message attributes**

The following ``set-sms-attributes`` example sets the default sender ID for SMS messages to ``MyName``. ::

    aws sns set-sms-attributes \
        --attributes DefaultSenderID=MyName

This command produces no output.
