**To opt-in for SMS messages**

The following ``opt-in-phone-number`` example opts the specified phone number into receiving SMS messages. ::

    aws sns opt-in-phone-number \
        --phone-number +1-555-555-0100

This command produces no output.
