**To list SMS message opt-outs**

The following ``list-phone-numbers-opted-out`` example lists the phone numbers opted out of receiving SMS messages. ::

    aws sns list-phone-numbers-opted-out

Output::

    {
        "phoneNumbers": [
            "+15555550100"
        ]
    }
