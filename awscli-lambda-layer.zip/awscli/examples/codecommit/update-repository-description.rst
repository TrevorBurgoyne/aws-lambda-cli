**To change the description for a repository**

This example changes the description for an AWS CodeCommit repository. This command produces output only if there are errors.

Command::

  aws codecommit update-repository-description --repository-name MyDemoRepo --repository-description "This description was changed"

Output::

  None.