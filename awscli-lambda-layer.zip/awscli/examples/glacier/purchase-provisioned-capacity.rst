**To purchase a provisioned capacity unit**

The following ``purchase-provisioned-capacity`` example purchases a provisioned capacity unit. ::

    aws glacier purchase-provisioned-capacity \
        --account-id 111122223333

Output::

    {
        "capacityId": "HpASAuvfRFiVDbOjMfEIcr8K"
    }
